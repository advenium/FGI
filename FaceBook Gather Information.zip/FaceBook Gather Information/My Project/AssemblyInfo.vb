﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("FaceBook Gather Information")> 
<Assembly: AssemblyDescription("OrphanageIllyrian")> 
<Assembly: AssemblyCompany("OrphanageIllyrian")> 
<Assembly: AssemblyProduct("FaceBook Gather Information")> 
<Assembly: AssemblyCopyright("Copyright © OrphanageIllyrian 2017")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("4bc91195-15b8-43b5-96f8-5f2bab7d0a34")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
